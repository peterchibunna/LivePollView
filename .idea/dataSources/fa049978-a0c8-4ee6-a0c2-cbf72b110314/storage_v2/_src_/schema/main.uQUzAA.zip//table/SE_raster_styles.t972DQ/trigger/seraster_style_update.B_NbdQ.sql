CREATE TRIGGER seraster_style_update
BEFORE UPDATE ON 'SE_raster_styles'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT,'update on SE_raster_styles violates constraint: not a valid SLD/SE Raster Style')
WHERE XB_IsSldSeRasterStyle(NEW.style) <> 1;
SELECT RAISE(ABORT,'update on SE_raster_styles violates constraint: not an XML Schema Validated SLD/SE Raster Style')
WHERE XB_IsSchemaValidated(NEW.style) <> 1;
END;

