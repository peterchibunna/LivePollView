CREATE TRIGGER raster_coverages_multisample_update
BEFORE UPDATE ON 'raster_coverages'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT, 'update on raster_coverages violates constraint: inconsistent MULTIBAND sample_type')
WHERE NEW.pixel_type = 'MULTIBAND' AND NEW.sample_type NOT IN ('UINT8', 'UINT16');
END;

