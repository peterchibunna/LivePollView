CREATE TRIGGER 'ISO_metadata_reference_scope_insert'
BEFORE INSERT ON 'ISO_metadata_reference'
FOR EACH ROW BEGIN
SELECT RAISE(ROLLBACK, 'insert on table ISO_metadata_reference violates constraint: reference_scope must be one of ''table'' | ''column'' | ''row'' | ''row/col''')
WHERE NOT NEW.reference_scope IN ('table','column','row','row/col');
END;

