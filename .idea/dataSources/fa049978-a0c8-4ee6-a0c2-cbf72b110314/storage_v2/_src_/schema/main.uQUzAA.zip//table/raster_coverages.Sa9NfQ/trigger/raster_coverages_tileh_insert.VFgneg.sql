CREATE TRIGGER raster_coverages_tileh_insert
BEFORE INSERT ON 'raster_coverages'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT,'insert on raster_coverages violates constraint: tile_height must be an exact multiple of 8 between 256 and 1024')
WHERE CastToInteger(NEW.tile_height) IS NULL OR NEW.tile_height NOT BETWEEN 256 AND 1024 OR (NEW.tile_height % 8) <> 0;
END;

