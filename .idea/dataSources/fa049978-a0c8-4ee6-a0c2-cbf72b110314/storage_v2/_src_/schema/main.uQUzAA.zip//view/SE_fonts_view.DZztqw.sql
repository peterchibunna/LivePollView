CREATE VIEW SE_fonts_view AS
SELECT font_facename AS font_facename, GetFontFamily(font) AS family_name, IsFontBold(font) AS bold, IsFontItalic(font) AS italic, font AS font
FROM SE_fonts;

