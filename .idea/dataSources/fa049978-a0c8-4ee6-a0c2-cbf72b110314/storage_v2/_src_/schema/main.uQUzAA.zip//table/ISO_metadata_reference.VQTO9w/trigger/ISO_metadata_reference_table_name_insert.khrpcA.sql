CREATE TRIGGER 'ISO_metadata_reference_table_name_insert'
BEFORE INSERT ON 'ISO_metadata_reference'
FOR EACH ROW BEGIN
SELECT RAISE(ROLLBACK, 'insert on table ISO_metadata_reference violates constraint: table_name must be the name of a table in geometry_columns')
WHERE NOT NEW.table_name IN (
SELECT f_table_name AS table_name FROM geometry_columns);
END;

