CREATE TRIGGER "tmu_main_state_location" AFTER UPDATE ON "main_state"
FOR EACH ROW BEGIN
UPDATE geometry_columns_time SET last_update = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
WHERE Lower(f_table_name) = Lower('main_state') AND Lower(f_geometry_column) = Lower('location');
END;

