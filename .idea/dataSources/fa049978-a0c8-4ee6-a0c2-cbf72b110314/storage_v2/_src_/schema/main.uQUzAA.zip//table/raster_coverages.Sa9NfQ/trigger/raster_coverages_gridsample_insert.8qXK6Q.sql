CREATE TRIGGER raster_coverages_gridsample_insert
BEFORE INSERT ON 'raster_coverages'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT,'insert on raster_coverages violates constraint: inconsistent DATAGRID sample_type')
WHERE NEW.pixel_type = 'DATAGRID' AND NEW.sample_type NOT IN ('INT8', 'UINT8', 'INT16', 'UINT16', 'INT32', 'UINT32', 'FLOAT', 'DOUBLE');
END;

