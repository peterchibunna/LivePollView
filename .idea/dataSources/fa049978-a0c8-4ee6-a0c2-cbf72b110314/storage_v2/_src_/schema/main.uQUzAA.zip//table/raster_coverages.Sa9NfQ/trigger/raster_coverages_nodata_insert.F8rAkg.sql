CREATE TRIGGER raster_coverages_nodata_insert
BEFORE INSERT ON 'raster_coverages'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT,'insert on raster_coverages violates constraint: invalid nodata_pixel')
WHERE NEW.nodata_pixel IS NOT NULL AND IsValidPixel(NEW.nodata_pixel, NEW.sample_type, NEW.num_bands) <> 1;
END;

