CREATE TRIGGER raster_coverages_pltsample_insert
BEFORE INSERT ON 'raster_coverages'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT,'insert on raster_coverages violates constraint: inconsistent PALETTE sample_type')
WHERE NEW.pixel_type = 'PALETTE' AND NEW.sample_type NOT IN ('1-BIT', '2-BIT', '4-BIT', 'UINT8');
END;

