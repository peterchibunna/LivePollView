CREATE TRIGGER vwgc_f_table_name_insert
BEFORE INSERT ON 'views_geometry_columns'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT,'insert on views_geometry_columns violates constraint: f_table_name value must not contain a single quote')
WHERE NEW.f_table_name LIKE ('%''%');
SELECT RAISE(ABORT,'insert on views_geometry_columns violates constraint: f_table_name value must not contain a double quote')
WHERE NEW.f_table_name LIKE ('%"%');
SELECT RAISE(ABORT,'insert on views_geometry_columns violates constraint: 
f_table_name value must be lower case')
WHERE NEW.f_table_name <> lower(NEW.f_table_name);
END;

