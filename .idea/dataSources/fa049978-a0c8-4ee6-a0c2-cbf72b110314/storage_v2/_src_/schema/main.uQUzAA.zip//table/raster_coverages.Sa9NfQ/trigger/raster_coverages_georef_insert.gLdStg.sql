CREATE TRIGGER raster_coverages_georef_insert
BEFORE INSERT ON 'raster_coverages'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT,'insert on raster_coverages violates constraint: inconsistent georeferencing infos')
WHERE NOT ((NEW.horz_resolution IS NULL AND NEW.vert_resolution IS NULL AND NEW.srid IS NULL) OR (NEW.horz_resolution IS NOT NULL AND NEW.vert_resolution IS NOT NULL AND NEW.srid IS NOT NULL));
END;

