CREATE TRIGGER raster_coverages_pltcompr_update
BEFORE UPDATE ON 'raster_coverages'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT, 'update on raster_coverages violates constraint: inconsistent PALETTE compression')
WHERE NEW.pixel_type = 'PALETTE' AND NEW.compression NOT IN ('NONE', 'DEFLATE', 'DEFLATE_NO', 'LZMA', 'LZMA_NO', 'LZ4', 'LZ4_NO', 'ZSTD', 'ZSTD_NO', 'PNG');
END;

