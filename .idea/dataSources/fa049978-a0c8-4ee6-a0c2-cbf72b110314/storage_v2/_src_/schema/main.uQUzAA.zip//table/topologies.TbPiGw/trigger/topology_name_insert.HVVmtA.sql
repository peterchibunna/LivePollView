CREATE TRIGGER topology_name_insert
BEFORE INSERT ON 'topologies'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT,'insert on topologies violates constraint: topology_name value must not contain a single quote')
WHERE NEW.topology_name LIKE ('%''%');
SELECT RAISE(ABORT,'insert on topologies violates constraint: topology_name value must not contain a double quote')
WHERE NEW.topology_name LIKE ('%"%');
SELECT RAISE(ABORT,'insert on topologies violates constraint: topology_name value must be lower case')
WHERE NEW.topology_name <> lower(NEW.topology_name);
END;

