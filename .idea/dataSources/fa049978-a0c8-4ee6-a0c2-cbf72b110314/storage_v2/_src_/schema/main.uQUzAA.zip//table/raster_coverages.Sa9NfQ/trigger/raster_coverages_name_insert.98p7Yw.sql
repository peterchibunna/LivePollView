CREATE TRIGGER raster_coverages_name_insert
BEFORE INSERT ON 'raster_coverages'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT,'insert on raster_coverages violates constraint: coverage_name value must not contain a single quote')
WHERE NEW.coverage_name LIKE ('%''%');
SELECT RAISE(ABORT,'insert on raster_coverages violates constraint: coverage_name value must not contain a double quote')
WHERE NEW.coverage_name LIKE ('%"%');
SELECT RAISE(ABORT,'insert on raster_coverages violates constraint: coverage_name value must be lower case')
WHERE NEW.coverage_name <> lower(NEW.coverage_name);
END;

