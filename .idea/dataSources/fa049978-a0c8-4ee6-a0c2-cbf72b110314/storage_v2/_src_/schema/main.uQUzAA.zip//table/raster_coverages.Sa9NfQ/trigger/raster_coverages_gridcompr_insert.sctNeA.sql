CREATE TRIGGER raster_coverages_gridcompr_insert
BEFORE INSERT ON 'raster_coverages'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT,'insert on raster_coverages violates constraint: inconsistent DATAGRID compression')
WHERE NEW.pixel_type = 'DATAGRID' AND (((NEW.sample_type NOT IN ('UINT8', 'UINT16')) AND NEW.compression NOT IN ('NONE', 'DEFLATE', 'DEFLATE_NO', 'LZMA', 'LZMA_NO', 'LZ4', 'LZ4_NO', 'ZSTD', 'ZSTD_NO')) OR ((NEW.sample_type IN ('UINT8', 'UINT16')) AND NEW.compression NOT IN ('NONE', 'DEFLATE', 'DEFLATE_NO', 'LZMA', 'LZMA_NO', 'LZ4', 'LZ4_NO', 'ZSTD', 'ZSTD_NO', 'PNG', 'LOSSY_JP2', 'LOSSLESS_JP2')));
END;

