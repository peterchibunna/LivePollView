CREATE TRIGGER vwgc_view_rowid_update
BEFORE UPDATE OF 'view_rowid' ON 'views_geometry_columns'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT,'update on views_geometry_columns violates constraint: view_rowid value must not contain a single quote')
WHERE NEW.f_geometry_column LIKE ('%''%');
SELECT RAISE(ABORT,'update on views_geometry_columns violates constraint: view_rowid value must not contain a double quote')
WHERE NEW.view_rowid LIKE ('%"%');
SELECT RAISE(ABORT,'update on views_geometry_columns violates constraint: view_rowid value must be lower case')
WHERE NEW.view_rowid <> lower(NEW.view_rowid);
END;

