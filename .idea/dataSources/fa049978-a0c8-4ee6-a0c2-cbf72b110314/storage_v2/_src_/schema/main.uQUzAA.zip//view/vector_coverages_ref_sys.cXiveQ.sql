CREATE VIEW vector_coverages_ref_sys AS
SELECT v.coverage_name AS coverage_name, v.title AS title, v.abstract AS abstract, v.is_queryable AS is_queryable, v.geo_minx AS geo_minx, v.geo_miny AS geo_miny, v.geo_maxx AS geo_maxx, v.geo_maxy AS geo_maxy, v.extent_minx AS extent_minx, v.extent_miny AS extent_miny, v.extent_maxx AS extent_maxx, v.extent_maxy AS extent_maxy, s.srid AS srid, 1 AS native_srid, s.auth_name AS auth_name, s.auth_srid AS auth_srid, s.ref_sys_name AS ref_sys_name, s.proj4text AS proj4text
FROM vector_coverages AS v
JOIN geometry_columns AS x ON (v.topology_name IS NULL AND v.network_name IS NULL AND v.f_table_name IS NOT NULL AND v.f_geometry_column IS NOT NULL AND v.f_table_name = x.f_table_name AND v.f_geometry_column = x.f_geometry_column)
LEFT JOIN spatial_ref_sys AS s ON (x.srid = s.srid)
UNION
SELECT v.coverage_name AS coverage_name, v.title AS title, v.abstract AS abstract, v.is_queryable AS is_queryable, v.geo_minx AS geo_minx, v.geo_miny AS geo_miny, v.geo_maxx AS geo_maxx, v.geo_maxy AS geo_maxy, v.extent_minx AS extent_minx, v.extent_miny AS extent_miny, v.extent_maxx AS extent_maxx, v.extent_maxy AS extent_maxy, s.srid AS srid, 1 AS native_srid, s.auth_name AS auth_name, s.auth_srid AS auth_srid, s.ref_sys_name AS ref_sys_name, s.proj4text AS proj4text
FROM vector_coverages AS v
JOIN views_geometry_columns AS y ON (v.view_name IS NOT NULL AND v.view_geometry IS NOT NULL AND v.view_name = y.view_name AND v.view_geometry = y.view_geometry)
JOIN geometry_columns AS x ON (y.f_table_name = x.f_table_name AND y.f_geometry_column = x.f_geometry_column)
LEFT JOIN spatial_ref_sys AS s ON (x.srid = s.srid)
UNION
SELECT v.coverage_name AS coverage_name, v.title AS title, v.abstract AS abstract, v.is_queryable AS is_queryable, v.geo_minx AS geo_minx, v.geo_miny AS geo_miny, v.geo_maxx AS geo_maxx, v.geo_maxy AS geo_maxy, v.extent_minx AS extent_minx, v.extent_miny AS extent_miny, v.extent_maxx AS extent_maxx, v.extent_maxy AS extent_maxy, s.srid AS srid, 1 AS native_srid, s.auth_name AS auth_name, s.auth_srid AS auth_srid, s.ref_sys_name AS ref_sys_name, s.proj4text AS proj4text
FROM vector_coverages AS v
JOIN virts_geometry_columns AS x ON (v.virt_name IS NOT NULL AND v.virt_geometry IS NOT NULL AND v.virt_name = x.virt_name AND v.virt_geometry = x.virt_geometry)
LEFT JOIN spatial_ref_sys AS s ON (x.srid = s.srid)
UNION
SELECT v.coverage_name AS coverage_name, v.title AS title, v.abstract AS abstract, v.is_queryable AS is_queryable, v.geo_minx AS geo_minx, v.geo_miny AS geo_miny, v.geo_maxx AS geo_maxx, v.geo_maxy AS geo_maxy, v.extent_minx AS extent_minx, v.extent_miny AS extent_miny, v.extent_maxx AS extent_maxx, v.extent_maxy AS extent_maxy, s.srid AS srid, 1 AS native_srid, s.auth_name AS auth_name, s.auth_srid AS auth_srid, s.ref_sys_name AS ref_sys_name, s.proj4text AS proj4text
FROM vector_coverages AS v
JOIN topologies AS x ON (v.topology_name IS NOT NULL AND v.topology_name = x.topology_name)
LEFT JOIN spatial_ref_sys AS s ON (x.srid = s.srid)
UNION
SELECT v.coverage_name AS coverage_name, v.title AS title, v.abstract AS abstract, v.is_queryable AS is_queryable, v.geo_minx AS geo_minx, v.geo_miny AS geo_miny, v.geo_maxx AS geo_maxx, v.geo_maxy AS geo_maxy, v.extent_minx AS extent_minx, v.extent_miny AS extent_miny, v.extent_maxx AS extent_maxx, v.extent_maxy AS extent_maxy, s.srid AS srid, 1 AS native_srid, s.auth_name AS auth_name, s.auth_srid AS auth_srid, s.ref_sys_name AS ref_sys_name, s.proj4text AS proj4text
FROM vector_coverages AS v
JOIN networks AS x ON (v.network_name IS NOT NULL AND v.network_name = x.network_name)
LEFT JOIN spatial_ref_sys AS s ON (x.srid = s.srid)
UNION
SELECT v.coverage_name AS coverage_name, v.title AS title, v.abstract AS abstract, v.is_queryable AS is_queryable, v.geo_minx AS geo_minx, v.geo_miny AS geo_miny, v.geo_maxx AS geo_maxx, v.geo_maxy AS geo_maxy, x.extent_minx AS extent_minx, x.extent_miny AS extent_miny, x.extent_maxx AS extent_maxx, x.extent_maxy AS extent_maxy, s.srid AS srid, 0 AS native_srid, s.auth_name AS auth_name, s.auth_srid AS auth_srid, s.ref_sys_name AS ref_sys_name, s.proj4text AS proj4text
FROM vector_coverages AS v
JOIN vector_coverages_srid AS x ON (v.coverage_name = x.coverage_name)
LEFT JOIN spatial_ref_sys AS s ON (x.srid = s.srid);

