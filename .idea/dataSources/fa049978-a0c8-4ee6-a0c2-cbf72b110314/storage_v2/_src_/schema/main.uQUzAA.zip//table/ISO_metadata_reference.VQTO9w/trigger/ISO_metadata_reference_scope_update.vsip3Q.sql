CREATE TRIGGER 'ISO_metadata_reference_scope_update'
BEFORE UPDATE OF 'reference_scope' ON 'ISO_metadata_reference'
FOR EACH ROW BEGIN
SELECT RAISE(ROLLBACK, 'update on table ISO_metadata_reference violates constraint: referrence_scope must be one of ''table'' | ''column'' | ''row'' | ''row/col''')
WHERE NOT NEW.reference_scope IN ('table','column','row','row/col');
END;

