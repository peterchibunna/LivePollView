CREATE TRIGGER network_name_insert
BEFORE INSERT ON 'networks'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT,'insert on networks violates constraint: network_name value must not contain a single quote')
WHERE NEW.network_name LIKE ('%''%');
SELECT RAISE(ABORT,'insert on networks violates constraint: network_name value must not contain a double quote')
WHERE NEW.network_name LIKE ('%"%');
SELECT RAISE(ABORT,'insert on networks violates constraint: network_name value must be lower case')
WHERE NEW.network_name <> lower(NEW.network_name);
END;

