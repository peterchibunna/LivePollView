CREATE TRIGGER raster_coverages_pltbands_update
BEFORE UPDATE ON 'raster_coverages'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT, 'update on raster_coverages violates constraint: inconsistent PALETTE num_bands')
WHERE NEW.pixel_type = 'PALETTE' AND NEW.num_bands <> 1;
END;

