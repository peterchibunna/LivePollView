CREATE TRIGGER vector_coverages_srid_name_insert
BEFORE INSERT ON 'vector_coverages_srid'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT,'insert on vector_coverages_srid violates constraint: coverage_name value must not contain a single quote')
WHERE NEW.coverage_name LIKE ('%''%');
SELECT RAISE(ABORT,'insert on vector_coverages_srid violates constraint: coverage_name value must not contain a double quote')
WHERE NEW.coverage_name LIKE ('%"%');
SELECT RAISE(ABORT,'insert on vector_coverages_srid violates constraint: coverage_name value must be lower case')
WHERE NEW.coverage_name <> lower(NEW.coverage_name);
END;

