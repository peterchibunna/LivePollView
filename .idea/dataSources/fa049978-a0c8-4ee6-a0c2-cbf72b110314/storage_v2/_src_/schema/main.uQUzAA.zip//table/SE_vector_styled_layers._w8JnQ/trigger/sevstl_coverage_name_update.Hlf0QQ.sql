CREATE TRIGGER sevstl_coverage_name_update
BEFORE UPDATE OF 'coverage_name' ON 'SE_vector_styled_layers'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT,'update on SE_vector_styled_layers violates constraint: coverage_name value must not contain a single quote')
WHERE NEW.coverage_name LIKE ('%''%');
SELECT RAISE(ABORT,'update on SE_vector_styled_layers violates constraint: coverage_name value must not contain a double quote')
WHERE NEW.coverage_name LIKE ('%"%');
SELECT RAISE(ABORT,'update on SE_vector_styled_layers violates constraint: coverage_name value must be lower case')
WHERE NEW.coverage_name <> lower(NEW.coverage_name);
END;

