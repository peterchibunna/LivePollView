CREATE TRIGGER raster_coverages_pixel_insert
BEFORE INSERT ON 'raster_coverages'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT,'insert on raster_coverages violates constraint: pixel_type must be one of ''MONOCHROME'' | ''PALETTE'' | ''GRAYSCALE'' | ''RGB'' | ''MULTIBAND'' | ''DATAGRID''')
WHERE NEW.pixel_type NOT IN ('MONOCHROME', 'PALETTE', 'GRAYSCALE', 'RGB', 'MULTIBAND', 'DATAGRID');
END;

