CREATE TRIGGER raster_coverages_sample_insert
BEFORE INSERT ON 'raster_coverages'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT,'insert on raster_coverages violates constraint: sample_type must be one of ''1-BIT'' | ''2-BIT'' | ''4-BIT'' | ''INT8'' | ''UINT8'' | ''INT16'' | ''UINT16'' | ''INT32'' | ''UINT32'' | ''FLOAT'' | ''DOUBLE''')
WHERE NEW.sample_type NOT IN ('1-BIT', '2-BIT', '4-BIT', 'INT8', 'UINT8', 'INT16', 'UINT16', 'INT32', 'UINT32', 'FLOAT', 'DOUBLE');
END;

