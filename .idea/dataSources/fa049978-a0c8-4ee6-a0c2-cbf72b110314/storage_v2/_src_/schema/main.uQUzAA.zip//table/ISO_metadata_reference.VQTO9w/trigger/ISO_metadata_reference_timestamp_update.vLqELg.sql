CREATE TRIGGER 'ISO_metadata_reference_timestamp_update'
BEFORE UPDATE OF 'timestamp' ON 'ISO_metadata_reference'
FOR EACH ROW BEGIN
SELECT RAISE(ROLLBACK, 'update on table ISO_metadata_reference violates constraint: timestamp must be a valid time in ISO 8601 ''yyyy-mm-ddThh:mm:ss.cccZ'' form')
WHERE NOT (NEW.timestamp GLOB'[1-2][0-9][0-9][0-9]-[0-1][0-9]-[1-3][0-9]T[0-2][0-9]:[0-5][0-9]:[0-5][0-9].[0-9][0-9][0-9]Z' AND strftime('%s',NEW.timestamp) NOT NULL);
END;

