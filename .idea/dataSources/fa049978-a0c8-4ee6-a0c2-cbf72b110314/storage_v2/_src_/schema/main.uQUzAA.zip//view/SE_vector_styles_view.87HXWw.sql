CREATE VIEW SE_vector_styles_view AS 
SELECT style_name AS name, XB_GetTitle(style) AS title, XB_GetAbstract(style) AS abstract, style AS style, XB_IsSchemaValidated(style) AS schema_validated, XB_GetSchemaURI(style) AS schema_uri
FROM SE_vector_styles;

