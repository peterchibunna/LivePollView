CREATE TRIGGER vwgcfi_view_name_insert
BEFORE INSERT ON 'views_geometry_columns_field_infos'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT,'insert on views_geometry_columns_field_infos violates constraint: view_name value must not contain a single quote')
WHERE NEW.view_name LIKE ('%''%');
SELECT RAISE(ABORT,'insert on views_geometry_columns_field_infos violates constraint: view_name value must not contain a double quote')
WHERE NEW.view_name LIKE ('%"%');
SELECT RAISE(ABORT,'insert on views_geometry_columns_field_infos violates constraint: 
view_name value must be lower case')
WHERE NEW.view_name <> lower(NEW.view_name);
END;

