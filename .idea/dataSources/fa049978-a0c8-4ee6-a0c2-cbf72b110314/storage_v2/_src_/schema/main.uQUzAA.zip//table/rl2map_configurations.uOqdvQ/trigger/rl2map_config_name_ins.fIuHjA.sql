CREATE TRIGGER rl2map_config_name_ins
AFTER INSERT ON 'rl2map_configurations'
FOR EACH ROW BEGIN
UPDATE rl2map_configurations SET name = XB_GetName(NEW.config) WHERE id = NEW.id;
END;

