CREATE TRIGGER vtgc_virt_geometry_update
BEFORE UPDATE OF 'virt_geometry' ON 'virts_geometry_columns'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT,'update on virts_geometry_columns violates constraint: virt_geometry value must not contain a single quote')
WHERE NEW.virt_geometry LIKE ('%''%');
SELECT RAISE(ABORT,'update on virts_geometry_columns violates constraint: 
virt_geometry value must not contain a double quote')
WHERE NEW.virt_geometry LIKE ('%"%');
SELECT RAISE(ABORT,'update on virts_geometry_columns violates constraint: virt_geometry value must be lower case')
WHERE NEW.virt_geometry <> lower(NEW.virt_geometry);
END;

