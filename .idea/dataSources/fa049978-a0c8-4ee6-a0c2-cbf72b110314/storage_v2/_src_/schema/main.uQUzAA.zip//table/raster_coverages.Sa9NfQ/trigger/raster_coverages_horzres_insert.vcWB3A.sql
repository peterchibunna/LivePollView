CREATE TRIGGER raster_coverages_horzres_insert
BEFORE INSERT ON 'raster_coverages'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT,'insert on raster_coverages violates constraint: horz_resolution must be positive')
WHERE NEW.horz_resolution IS NOT NULL AND (NEW.horz_resolution <= 0.0 OR CastToDouble(NEW.horz_resolution) IS NULL);
END;

