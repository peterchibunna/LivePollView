CREATE TRIGGER raster_coverages_monosample_insert
BEFORE INSERT ON 'raster_coverages'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT,'insert on raster_coverages violates constraint: inconsistent MONOCHROME sample_type')
WHERE NEW.pixel_type = 'MONOCHROME' AND NEW.sample_type <> '1-BIT';
END;

