CREATE VIEW rl2map_configurations_view AS 
SELECT name AS name, XB_GetTitle(config) AS title, XB_GetAbstract(config) AS abstract, config AS config, XB_IsSchemaValidated(config) AS schema_validated, XB_GetSchemaURI(config) AS schema_uri
FROM rl2map_configurations;

