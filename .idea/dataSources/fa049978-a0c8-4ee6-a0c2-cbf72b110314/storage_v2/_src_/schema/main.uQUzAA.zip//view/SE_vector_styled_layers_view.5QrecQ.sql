CREATE VIEW SE_vector_styled_layers_view AS 
SELECT l.coverage_name AS coverage_name, v.f_table_name AS f_table_name, v.f_geometry_column AS f_geometry_column, l.style_id AS style_id, s.style_name AS name, XB_GetTitle(s.style) AS title, XB_GetAbstract(s.style) AS abstract, s.style AS style, XB_IsSchemaValidated(s.style) AS schema_validated, XB_GetSchemaURI(s.style) AS schema_uri
FROM SE_vector_styled_layers AS l
JOIN vector_coverages AS v ON (l.coverage_name = v.coverage_name) JOIN SE_vector_styles AS s ON (l.style_id = s.style_id);

