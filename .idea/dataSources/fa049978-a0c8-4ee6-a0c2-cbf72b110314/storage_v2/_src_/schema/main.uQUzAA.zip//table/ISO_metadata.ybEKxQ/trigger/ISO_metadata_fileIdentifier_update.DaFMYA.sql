CREATE TRIGGER 'ISO_metadata_fileIdentifier_update'
AFTER UPDATE ON 'ISO_metadata'
FOR EACH ROW BEGIN
UPDATE ISO_metadata SET fileId = XB_GetFileId(NEW.metadata), parentId = XB_GetParentId(NEW.metadata), geometry = XB_GetGeometry(NEW.metadata) WHERE id = NEW.id;
UPDATE ISO_metadata_reference SET md_parent_id = GetIsoMetadataId(NEW.parentId) WHERE md_file_id = NEW.id;
END;

