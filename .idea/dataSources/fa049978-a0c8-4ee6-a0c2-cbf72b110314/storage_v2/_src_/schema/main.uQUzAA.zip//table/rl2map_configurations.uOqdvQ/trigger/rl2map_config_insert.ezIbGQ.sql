CREATE TRIGGER rl2map_config_insert
BEFORE INSERT ON 'rl2map_configurations'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT,'insert on rl2map_configurations violates constraint: not a valid RL2MapConfig')
WHERE XB_IsMapConfig(NEW.config) <> 1;
SELECT RAISE(ABORT,'insert on rl2map_configurations violates constraint: not an XML Schema Validated RL2MapConfig')
WHERE XB_IsSchemaValidated(NEW.config) <> 1;
END;

