CREATE TRIGGER topology_name_update
BEFORE UPDATE OF 'topology_name' ON 'topologies'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT,'update on topologies violates constraint: topology_name value must not contain a single quote')
WHERE NEW.topology_name LIKE ('%''%');
SELECT RAISE(ABORT,'update on topologies violates constraint: topology_name value must not contain a double quote')
WHERE NEW.topology_name LIKE ('%"%');
SELECT RAISE(ABORT,'update on topologies violates constraint: topology_name value must be lower case')
WHERE NEW.topology_name <> lower(NEW.topology_name);
END;

