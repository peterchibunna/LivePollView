CREATE TRIGGER "ggu_ISO_metadata_geometry" BEFORE UPDATE OF "geometry" ON "ISO_metadata"
FOR EACH ROW BEGIN
SELECT RAISE(ROLLBACK, 'ISO_metadata.geometry violates Geometry constraint [geom-type or SRID not allowed]')
WHERE (SELECT geometry_type FROM geometry_columns
WHERE Lower(f_table_name) = Lower('ISO_metadata') AND Lower(f_geometry_column) = Lower('geometry')
AND GeometryConstraints(NEW."geometry", geometry_type, srid) = 1) IS NULL;
END;

