CREATE TRIGGER "tmi_ISO_metadata_geometry" AFTER INSERT ON "ISO_metadata"
FOR EACH ROW BEGIN
UPDATE geometry_columns_time SET last_insert = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
WHERE Lower(f_table_name) = Lower('ISO_metadata') AND Lower(f_geometry_column) = Lower('geometry');
END;

