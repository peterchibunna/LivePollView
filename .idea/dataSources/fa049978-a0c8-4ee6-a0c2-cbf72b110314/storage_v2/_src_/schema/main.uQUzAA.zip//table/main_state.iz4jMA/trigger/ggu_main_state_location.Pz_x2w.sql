CREATE TRIGGER "ggu_main_state_location" BEFORE UPDATE OF "location" ON "main_state"
FOR EACH ROW BEGIN
SELECT RAISE(ROLLBACK, 'main_state.location violates Geometry constraint [geom-type or SRID not allowed]')
WHERE (SELECT geometry_type FROM geometry_columns
WHERE Lower(f_table_name) = Lower('main_state') AND Lower(f_geometry_column) = Lower('location')
AND GeometryConstraints(NEW."location", geometry_type, srid) = 1) IS NULL;
END;

