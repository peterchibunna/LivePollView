CREATE TRIGGER 'ISO_metadata_md_scope_insert'
BEFORE INSERT ON 'ISO_metadata'
FOR EACH ROW BEGIN
SELECT RAISE(ROLLBACK, 'insert on table ISO_metadata violates constraint: md_scope must be one of ''undefined'' | ''fieldSession'' | ''collectionSession'' | ''series'' | ''dataset'' | ''featureType'' | ''feature'' | ''attributeType'' | ''attribute'' | ''tile'' | ''model'' | ''catalogue'' | ''schema'' | ''taxonomy'' | ''software'' | ''service'' | ''collectionHardware'' | ''nonGeographicDataset'' | ''dimensionGroup''')
WHERE NOT(NEW.md_scope IN ('undefined','fieldSession','collectionSession','series','dataset','featureType','feature','attributeType','attribute','tile','model','catalogue','schema','taxonomy','software','service','collectionHardware','nonGeographicDataset','dimensionGroup'));
END;

