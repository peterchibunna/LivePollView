CREATE VIEW vector_layers AS
SELECT 'SpatialTable' AS layer_type, f_table_name AS table_name, f_geometry_column AS geometry_column, geometry_type AS geometry_type, coord_dimension AS coord_dimension, srid AS srid, spatial_index_enabled AS spatial_index_enabled
FROM geometry_columns
UNION
SELECT 'SpatialView' AS layer_type, a.view_name AS table_name, a.view_geometry AS geometry_column, b.geometry_type AS geometry_type, b.coord_dimension AS coord_dimension, b.srid AS srid, b.spatial_index_enabled AS spatial_index_enabled
FROM views_geometry_columns AS a
LEFT JOIN geometry_columns AS b ON (Upper(a.f_table_name) = Upper(b.f_table_name) AND Upper(a.f_geometry_column) = Upper(b.f_geometry_column))
UNION
SELECT 'VirtualShape' AS layer_type, virt_name AS table_name, virt_geometry AS geometry_column, geometry_type AS geometry_type, coord_dimension AS coord_dimension, srid AS srid, 0 AS spatial_index_enabled
FROM virts_geometry_columns;

