CREATE TRIGGER raster_coverages_rgbbands_insert
BEFORE INSERT ON 'raster_coverages'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT,'insert on raster_coverages violates constraint: inconsistent RGB num_bands')
WHERE NEW.pixel_type = 'RGB' AND NEW.num_bands <> 3;
END;

