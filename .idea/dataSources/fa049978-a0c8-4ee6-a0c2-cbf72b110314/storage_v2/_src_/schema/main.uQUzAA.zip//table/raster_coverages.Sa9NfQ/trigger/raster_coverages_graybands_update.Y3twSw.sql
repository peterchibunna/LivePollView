CREATE TRIGGER raster_coverages_graybands_update
BEFORE UPDATE ON 'raster_coverages'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT, 'update on raster_coverages violates constraint: inconsistent GRAYSCALE num_bands')
WHERE NEW.pixel_type = 'GRAYSCALE' AND NEW.num_bands <> 1;
END;

