CREATE TRIGGER raster_coverages_palette_update
BEFORE UPDATE OF 'palette' ON 'raster_coverages'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT, 'update on raster_coverages violates constraint: invalid palette')
WHERE NEW.palette IS NOT NULL AND (NEW.pixel_type <> 'PALETTE' OR NEW.num_bands <> 1 OR IsValidRasterPalette(NEW.palette, NEW.sample_type) <> 1);
END;

