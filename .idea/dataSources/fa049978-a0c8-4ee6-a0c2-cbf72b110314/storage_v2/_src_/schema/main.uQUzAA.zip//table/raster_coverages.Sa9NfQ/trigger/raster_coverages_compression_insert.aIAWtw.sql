CREATE TRIGGER raster_coverages_compression_insert
BEFORE INSERT ON 'raster_coverages'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT,'insert on raster_coverages violates constraint: compression must be one of ''NONE'' | ''DEFLATE'' | ''DEFLATE_NO'' | ''LZMA'' | ''LZMA_NO'' | ''LZ4'' | ''LZ4_NO'' | ''ZSTD'' | ''ZSTD_NO'' | ''PNG'' | ''JPEG'' | ''LOSSY_WEBP'' | ''LOSSLESS_WEBP'' | ''CCITTFAX4'' | ''LOSSY_JP2'' | ''LOSSLESS_JP2''')
WHERE NEW.compression NOT IN ('NONE', 'DEFLATE',  'DEFLATE_NO', 'LZMA', 'LZMA_NO', 'LZ4', 'LZ4_NO', 'ZSTD', 'ZSTD_NO', 'PNG', 'JPEG', 'LOSSY_WEBP', 'LOSSLESS_WEBP', 'CCITTFAX4', 'LOSSY_JP2', 'LOSSLESS_JP2');
END;

