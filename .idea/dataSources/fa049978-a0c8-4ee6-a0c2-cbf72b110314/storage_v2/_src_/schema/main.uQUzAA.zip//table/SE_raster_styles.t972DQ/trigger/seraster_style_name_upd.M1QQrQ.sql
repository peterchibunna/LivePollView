CREATE TRIGGER seraster_style_name_upd
AFTER UPDATE OF style ON 'SE_raster_styles'
FOR EACH ROW BEGIN
UPDATE SE_raster_styles SET style_name = XB_GetName(NEW.style) WHERE style_id = NEW.style_id;
END;

