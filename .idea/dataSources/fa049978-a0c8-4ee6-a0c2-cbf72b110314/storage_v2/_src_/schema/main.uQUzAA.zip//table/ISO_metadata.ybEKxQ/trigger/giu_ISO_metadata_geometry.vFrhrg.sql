CREATE TRIGGER "giu_ISO_metadata_geometry" AFTER UPDATE OF "geometry" ON "ISO_metadata"
FOR EACH ROW BEGIN
DELETE FROM "idx_ISO_metadata_geometry" WHERE pkid=NEW.ROWID;
SELECT RTreeAlign('idx_ISO_metadata_geometry', NEW.ROWID, NEW."geometry");
END;

