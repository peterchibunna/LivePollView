CREATE TRIGGER raster_coverages_delete
BEFORE DELETE ON 'raster_coverages'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT, 'delete on raster_coverages violates constraint: attempting to delete the definition of an already populated Coverage')
WHERE IsPopulatedCoverage(NULL, OLD.coverage_name) = 1;
END;

