CREATE TRIGGER rl2map_config_name_upd
AFTER UPDATE OF config ON 'rl2map_configurations'
FOR EACH ROW BEGIN
UPDATE rl2map_configurations SET name = XB_GetName(NEW.config) WHERE id = NEW.id;
END;

