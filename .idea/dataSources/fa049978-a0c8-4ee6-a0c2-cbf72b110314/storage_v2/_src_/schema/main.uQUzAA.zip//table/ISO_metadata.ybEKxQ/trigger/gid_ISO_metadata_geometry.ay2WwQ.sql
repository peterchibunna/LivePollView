CREATE TRIGGER "gid_ISO_metadata_geometry" AFTER DELETE ON "ISO_metadata"
FOR EACH ROW BEGIN
DELETE FROM "idx_ISO_metadata_geometry" WHERE pkid=OLD.ROWID;
END;

