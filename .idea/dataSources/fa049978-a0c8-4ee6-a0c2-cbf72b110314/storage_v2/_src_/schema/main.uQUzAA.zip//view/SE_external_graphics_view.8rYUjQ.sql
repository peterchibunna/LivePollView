CREATE VIEW SE_external_graphics_view AS
SELECT xlink_href AS xlink_href, title AS title, abstract AS abstract, resource AS resource, file_name AS file_name, GetMimeType(resource) AS mime_type
FROM SE_external_graphics;

