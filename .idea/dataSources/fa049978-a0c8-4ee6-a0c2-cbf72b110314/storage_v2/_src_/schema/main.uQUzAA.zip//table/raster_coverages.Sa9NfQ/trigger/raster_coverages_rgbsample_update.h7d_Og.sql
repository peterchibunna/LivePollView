CREATE TRIGGER raster_coverages_rgbsample_update
BEFORE UPDATE ON 'raster_coverages'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT, 'update on raster_coverages violates constraint: inconsistent RGB sample_type')
WHERE NEW.pixel_type = 'RGB' AND NEW.sample_type NOT IN ('UINT8', 'UINT16');
END;

