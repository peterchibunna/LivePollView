CREATE TRIGGER raster_coverages_update
BEFORE UPDATE ON 'raster_coverages'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT, 'update on raster_coverages violates constraint: attempting to change the definition of an already populated Coverage')
WHERE IsPopulatedCoverage(NULL, OLD.coverage_name) = 1 AND ((OLD.sample_type <> NEW.sample_type) AND (OLD.pixel_type <> NEW.sample_type) OR (OLD.num_bands <> NEW.num_bands) OR (OLD.compression <> NEW.compression) OR (OLD.quality <> NEW.quality) OR (OLD.tile_width <> NEW.tile_width) OR (OLD.tile_height <> NEW.tile_height) OR (OLD.horz_resolution <> NEW.horz_resolution) OR (OLD.vert_resolution <> NEW.vert_resolution) OR (OLD.srid <> NEW.srid) OR (OLD.nodata_pixel <> NEW.nodata_pixel));
END;

