CREATE TRIGGER seraster_style_insert
BEFORE INSERT ON 'SE_raster_styles'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT,'insert on SE_raster_styles violates constraint: not a valid SLD/SE Raster Style')
WHERE XB_IsSldSeRasterStyle(NEW.style) <> 1;
SELECT RAISE(ABORT,'insert on SE_raster_styles violates constraint: not an XML Schema Validated SLD/SE Raster Style')
WHERE XB_IsSchemaValidated(NEW.style) <> 1;
END;

