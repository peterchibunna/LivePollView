CREATE TRIGGER raster_coverages_vertres_insert
BEFORE INSERT ON 'raster_coverages'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT,'insert on raster_coverages violates constraint: vert_resolution must be positive')
WHERE NEW.vert_resolution IS NOT NULL AND (NEW.vert_resolution <= 0.0 OR CastToDouble(NEW.vert_resolution) IS NULL);
END;

