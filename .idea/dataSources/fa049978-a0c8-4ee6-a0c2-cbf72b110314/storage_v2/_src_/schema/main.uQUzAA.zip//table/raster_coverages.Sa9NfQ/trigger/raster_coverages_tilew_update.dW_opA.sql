CREATE TRIGGER raster_coverages_tilew_update
BEFORE UPDATE OF 'tile_width' ON 'raster_coverages'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT, 'update on raster_coverages violates constraint: tile_width must be an exact multiple of 8 between 256 and 1024')
WHERE CastToInteger(NEW.tile_width) IS NULL OR NEW.tile_width NOT BETWEEN 256 AND 1024 OR (NEW.tile_width % 8) <> 0;
END;

