CREATE TRIGGER raster_coverages_vertres_update
BEFORE UPDATE OF 'vert_resolution' ON 'raster_coverages'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT, 'update on raster_coverages violates constraint: vert_resolution must be positive')
WHERE NEW.vert_resolution IS NOT NULL AND (NEW.vert_resolution <= 0.0 OR CastToDouble(NEW.vert_resolution) IS NULL);
END;

