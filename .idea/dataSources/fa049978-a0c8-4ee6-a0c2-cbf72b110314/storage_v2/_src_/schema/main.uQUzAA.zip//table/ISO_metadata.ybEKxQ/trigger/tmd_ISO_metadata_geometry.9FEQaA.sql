CREATE TRIGGER "tmd_ISO_metadata_geometry" AFTER DELETE ON "ISO_metadata"
FOR EACH ROW BEGIN
UPDATE geometry_columns_time SET last_delete = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
WHERE Lower(f_table_name) = Lower('ISO_metadata') AND Lower(f_geometry_column) = Lower('geometry');
END;

