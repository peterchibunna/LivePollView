CREATE TRIGGER sevector_style_name_ins
AFTER INSERT ON 'SE_vector_styles'
FOR EACH ROW BEGIN
UPDATE SE_vector_styles SET style_name = XB_GetName(NEW.style) WHERE style_id = NEW.style_id;
END;

