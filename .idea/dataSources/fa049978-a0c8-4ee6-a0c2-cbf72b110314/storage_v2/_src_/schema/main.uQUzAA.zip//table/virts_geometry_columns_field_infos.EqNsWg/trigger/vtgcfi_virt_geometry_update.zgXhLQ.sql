CREATE TRIGGER vtgcfi_virt_geometry_update
BEFORE UPDATE OF 'virt_geometry' ON 'virts_geometry_columns_field_infos'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT,'update on virts_geometry_columns_field_infos violates constraint: virt_geometry value must not contain a single quote')
WHERE NEW.virt_geometry LIKE ('%''%');
SELECT RAISE(ABORT,'update on virts_geometry_columns_field_infos violates constraint: 
virt_geometry value must not contain a double quote')
WHERE NEW.virt_geometry LIKE ('%"%');
SELECT RAISE(ABORT,'update on virts_geometry_columns_field_infos violates constraint: virt_geometry value must be lower case')
WHERE NEW.virt_geometry <> lower(NEW.virt_geometry);
END;

