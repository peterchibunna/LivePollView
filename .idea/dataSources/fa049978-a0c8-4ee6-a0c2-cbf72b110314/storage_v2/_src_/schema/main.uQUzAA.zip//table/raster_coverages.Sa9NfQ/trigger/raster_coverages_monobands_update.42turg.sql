CREATE TRIGGER raster_coverages_monobands_update
BEFORE UPDATE ON 'raster_coverages'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT, 'update on raster_coverages violates constraint: inconsistent MONOCHROME num_bands')
WHERE NEW.pixel_type = 'MONOCHROME' AND NEW.num_bands <> 1;
END;

