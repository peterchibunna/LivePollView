CREATE TRIGGER raster_coverages_statistics_insert
BEFORE INSERT ON 'raster_coverages'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT,'insert on raster_coverages violates constraint: invalid statistics')
WHERE NEW.statistics IS NOT NULL AND IsValidRasterStatistics(NEW.statistics, NEW.sample_type, NEW.num_bands) <> 1;
END;

