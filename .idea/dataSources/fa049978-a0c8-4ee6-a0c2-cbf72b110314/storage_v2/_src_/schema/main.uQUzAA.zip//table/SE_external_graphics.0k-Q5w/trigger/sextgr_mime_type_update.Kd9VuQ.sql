CREATE TRIGGER sextgr_mime_type_update
BEFORE UPDATE OF 'mime_type' ON 'SE_external_graphics'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT, 'update on SE_external_graphics violates constraint: GetMimeType(resource) must be one of ''image/gif'' | ''image/png'' | ''image/jpeg'' | ''image/svg+xml''')
WHERE GetMimeType(NEW.resource) NOT IN ('image/gif', 'image/png', 'image/jpeg', 'image/svg+xml');
END;

