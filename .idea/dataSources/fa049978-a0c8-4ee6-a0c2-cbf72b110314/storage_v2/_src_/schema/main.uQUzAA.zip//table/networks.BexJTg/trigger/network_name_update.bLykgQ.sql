CREATE TRIGGER network_name_update
BEFORE UPDATE OF 'network_name' ON 'networks'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT,'update on networks violates constraint: network_name value must not contain a single quote')
WHERE NEW.network_name LIKE ('%''%');
SELECT RAISE(ABORT,'update on networks violates constraint: network_name value must not contain a double quote')
WHERE NEW.network_name LIKE ('%"%');
SELECT RAISE(ABORT,'update on networks violates constraint: network_name value must be lower case')
WHERE NEW.network_name <> lower(NEW.network_name);
END;

