CREATE TRIGGER raster_coverages_multibands_update
BEFORE UPDATE ON 'raster_coverages'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT, 'update on raster_coverages violates constraint: inconsistent MULTIBAND num_bands')
WHERE NEW.pixel_type = 'MULTIBAND' AND NEW.num_bands < 2;
END;

