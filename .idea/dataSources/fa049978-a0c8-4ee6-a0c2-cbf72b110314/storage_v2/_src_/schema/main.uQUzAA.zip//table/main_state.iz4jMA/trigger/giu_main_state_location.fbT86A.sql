CREATE TRIGGER "giu_main_state_location" AFTER UPDATE OF "location" ON "main_state"
FOR EACH ROW BEGIN
DELETE FROM "idx_main_state_location" WHERE pkid=NEW.ROWID;
SELECT RTreeAlign('idx_main_state_location', NEW.ROWID, NEW."location");
END;

