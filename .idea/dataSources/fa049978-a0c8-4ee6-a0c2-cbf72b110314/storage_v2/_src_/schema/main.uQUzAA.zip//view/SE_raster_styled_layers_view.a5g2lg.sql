CREATE VIEW SE_raster_styled_layers_view AS 
SELECT l.coverage_name AS coverage_name, l.style_id AS style_id, s.style_name AS name, XB_GetTitle(s.style) AS title, XB_GetAbstract(s.style) AS abstract, s.style AS style, XB_IsSchemaValidated(s.style) AS schema_validated, XB_GetSchemaURI(s.style) AS schema_uri
FROM SE_raster_styled_layers AS l
JOIN SE_raster_styles AS s ON (l.style_id = s.style_id);

