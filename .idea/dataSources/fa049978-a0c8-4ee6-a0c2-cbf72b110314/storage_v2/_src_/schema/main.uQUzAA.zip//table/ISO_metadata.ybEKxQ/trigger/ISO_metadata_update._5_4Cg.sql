CREATE TRIGGER ISO_metadata_update
BEFORE UPDATE ON 'ISO_metadata'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT,'update on ISO_metadata violates constraint: not a valid ISO Metadata XML')
WHERE XB_IsIsoMetadata(NEW.metadata) <> 1 AND NEW.id <> 0;
SELECT RAISE(ABORT,'update on ISO_metadata violates constraint: not an XML Schema Validated ISO Metadata')
WHERE XB_IsSchemaValidated(NEW.metadata) <> 1 AND NEW.id <> 0;
END;

