CREATE TRIGGER vwgc_f_table_name_update
BEFORE UPDATE OF 'f_table_name' ON 'views_geometry_columns'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT,'update on views_geometry_columns violates constraint: f_table_name value must not contain a single quote')
WHERE NEW.f_table_name LIKE ('%''%');
SELECT RAISE(ABORT,'update on views_geometry_columns violates constraint: f_table_name value must not contain a double quote')
WHERE NEW.f_table_name LIKE ('%"%');
SELECT RAISE(ABORT,'update on views_geometry_columns violates constraint: f_table_name value must be lower case')
WHERE NEW.f_table_name <> lower(NEW.f_table_name);
END;

