CREATE TRIGGER sevector_style_insert
BEFORE INSERT ON 'SE_vector_styles'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT,'insert on SE_vector_styles violates constraint: not a valid SLD/SE Vector Style')
WHERE XB_IsSldSeVectorStyle(NEW.style) <> 1;
SELECT RAISE(ABORT,'insert on SE_vector_styles violates constraint: not an XML Schema Validated SLD/SE Vector Style')
WHERE XB_IsSchemaValidated(NEW.style) <> 1;
END;

