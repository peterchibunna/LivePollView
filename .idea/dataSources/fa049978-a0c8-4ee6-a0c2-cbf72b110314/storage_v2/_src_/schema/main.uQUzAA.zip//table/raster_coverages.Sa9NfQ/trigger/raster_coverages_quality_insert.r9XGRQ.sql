CREATE TRIGGER raster_coverages_quality_insert
BEFORE INSERT ON 'raster_coverages'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT,'insert on raster_coverages violates constraint: quality must be between 0 and 100')
WHERE NEW.quality NOT BETWEEN 0 AND 100;
END;

