CREATE TRIGGER "gii_main_state_location" AFTER INSERT ON "main_state"
FOR EACH ROW BEGIN
DELETE FROM "idx_main_state_location" WHERE pkid=NEW.ROWID;
SELECT RTreeAlign('idx_main_state_location', NEW.ROWID, NEW."location");
END;

