CREATE TRIGGER raster_coverages_monosample_update
BEFORE UPDATE ON 'raster_coverages'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT, 'update on raster_coverages violates constraint: inconsistent MONOCHROME sample_type')
WHERE NEW.pixel_type = 'MONOCHROME' AND NEW.sample_type <>'1-BIT';
END;

