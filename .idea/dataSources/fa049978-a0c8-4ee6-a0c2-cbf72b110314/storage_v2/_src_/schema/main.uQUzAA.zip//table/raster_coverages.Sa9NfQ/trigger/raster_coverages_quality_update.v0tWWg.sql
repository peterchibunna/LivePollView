CREATE TRIGGER raster_coverages_quality_update
BEFORE UPDATE OF 'quality' ON 'raster_coverages'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT, 'update on raster_coverages violates constraint: quality must be between 0 and 100')
WHERE NEW.quality NOT BETWEEN 0 AND 100;
END;

