CREATE TRIGGER "gid_main_state_location" AFTER DELETE ON "main_state"
FOR EACH ROW BEGIN
DELETE FROM "idx_main_state_location" WHERE pkid=OLD.ROWID;
END;

