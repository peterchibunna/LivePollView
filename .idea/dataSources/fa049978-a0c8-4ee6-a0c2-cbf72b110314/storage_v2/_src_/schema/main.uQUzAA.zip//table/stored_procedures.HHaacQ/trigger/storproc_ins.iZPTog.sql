CREATE TRIGGER storproc_ins BEFORE INSERT ON stored_procedures
FOR EACH ROW BEGIN
SELECT RAISE(ROLLBACK, 'Invalid "sql_proc": not a BLOB of the SQL Procedure type')
WHERE SqlProc_IsValid(NEW.sql_proc) <> 1;
END;

