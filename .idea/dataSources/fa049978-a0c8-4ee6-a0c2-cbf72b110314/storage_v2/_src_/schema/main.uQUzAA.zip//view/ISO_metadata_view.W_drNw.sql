CREATE VIEW ISO_metadata_view AS
SELECT id AS id, md_scope AS md_scope, XB_GetTitle(metadata) AS title, XB_GetAbstract(metadata) AS abstract, geometry AS geometry, fileId AS fileIdentifier, parentId AS parentIdentifier, metadata AS metadata, XB_IsSchemaValidated(metadata) AS schema_validated, XB_GetSchemaURI(metadata) AS metadata_schema_URI
FROM ISO_metadata;

